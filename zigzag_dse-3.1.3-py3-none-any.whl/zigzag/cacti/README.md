# Cacti7_automation

Run CACTI7 in batches and auto-generate mem_pool.yaml, which is required by ZigZag as input file.

Use commends:
```
cd ./cacti-master
python3 cacti_top.py
```
To get more configuration details, you can read the comments in "cacti_top.py" and "cacti_config_creator.py".
